var __wpo = {
  "assets": {
    "main": [
      "/e84d016a97d0d2236c6781f0967a60c0.png",
      "/375bbc97a1f23fd526623e97a3b12019.png",
      "/5f291dc27e6a1ae078dbfe0c37279d3a.jpg",
      "/8df700de394b4d4835aad953ae91f2b0.jpg",
      "/3c9373351e50c3c2b891b51ab0a297e8.jpg",
      "/3ee4563425cf5a5eacb1e40645950b7e.jpg",
      "/b96e67fa2f1af8594396cb38d748d206.png",
      "/8dfc3a86e0bfa8ebce86739587fb6b3b.png",
      "/72d1558ffec8036ae45902e17be79237.jpg",
      "/f3ae69b9992ce7379b9f50f25675ab47.jpg",
      "/910aa9bcd49671470b1ac1ab206ab781.png",
      "/ab42b983bd8ec1a8e107d335a5b3074d.jpg",
      "/4df4f8297bc9cc95b9b7e51cec489ea4.png",
      "/06e54ca417fae5503440a69e3b0a955a.jpg",
      "/da2a673b4b348694aa75ec206269f93e.png",
      "/ecb09fe04f46199dddac4049dce7d135.jpg",
      "/75b4247fdd3b97d0e3b8e07b115673c2.ttf",
      "/d88db58844b8d55402d040e81e2589ec.jpg",
      "/4bb125e48b66834a148b561dc9193bb1.png",
      "/7c74c6e7de7bf5dadedf03c0b304295c.svg",
      "/b03cc7b0cd3f76a1bcfcaa3704711a21.jpg",
      "/b86a77f2d5871ba2029b7f890fb7b8dd.jpg",
      "/9e153768735edc4ed0fb2f1b033bf5f4.jpg",
      "/758033941cc747f5217ec368434314e1.jpg",
      "/8e839933a86a6f6bd705cfe828e14955.jpg",
      "/7802d8b27fcb19893ce6b38c0789268e.ttf",
      "/e0189803d576d6c0bbbdea5cd44399a0.jpg",
      "/121878e5d8ae0d1b71a5581c5a1d4342.png",
      "/0becfa536b0f09ff258466480ff62bc6.png",
      "/30af3eadb49441a545f69fa9ffa3e0b0.jpg",
      "/38b405eba92acbb5aef45d8152f2a736.ttf",
      "/dd5eff093c22e60565058dac94309328.jpg",
      "/76ca740617fd7c767ed4fe28d109a336.jpg",
      "/51a723d846f1c5c6f1a8794a9728f39b.jpg",
      "/4e8206207de39d7524873a3b3c2ba0e4.png",
      "/0854c2bf4c5166d93899ceb016f84f4a.png",
      "/2ec8557460d3a2cd7340b16ac84fce32.ttf",
      "/runtime.fd9503845a78ab8446f1.js",
      "/"
    ],
    "additional": [
      "/npm.intl.4f570d628d17626bef82.chunk.js",
      "/main.21df9a0faec5a60ba497.chunk.js",
      "/npm.ant-design.9e820277688125a812f2.chunk.js",
      "/npm.antd.92f33e1f38252f07bd43.chunk.js",
      "/npm.antv.5c4ba923288144dd282d.chunk.js",
      "/npm.core-js.bf8479ba8742ced8a2f4.chunk.js",
      "/npm.dagre.6814a1d78b559504ce37.chunk.js",
      "/npm.draft-js.c6b4da629b426692df96.chunk.js",
      "/npm.graphlib.05441218e663c5de62c3.chunk.js",
      "/npm.moment.2fb61346e735533abd37.chunk.js",
      "/npm.rc-align.a4af2a46dd285eef9329.chunk.js",
      "/12.e85530c1149c86b5e89e.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "a79c3011d2778df2b8d46bfb8ac675665583daf9": "/e84d016a97d0d2236c6781f0967a60c0.png",
    "ff768da229e9d0028142381e06244ee3e00889a0": "/375bbc97a1f23fd526623e97a3b12019.png",
    "f4a7ea13f2711b211f0961fade6b695e1c8a7f36": "/5f291dc27e6a1ae078dbfe0c37279d3a.jpg",
    "94a26a07f74c44a889430eaf50175b9810192265": "/8df700de394b4d4835aad953ae91f2b0.jpg",
    "b60a9c142d1dd649f3f4f897ebc7c32ca7f73ed8": "/3c9373351e50c3c2b891b51ab0a297e8.jpg",
    "ffa15b83bb69a67db21bf7abec36191f4d56844b": "/3ee4563425cf5a5eacb1e40645950b7e.jpg",
    "b35bd6d7984589f65de1dde2e07cd400c47ef145": "/b96e67fa2f1af8594396cb38d748d206.png",
    "20365867d1a06afce3067e87c55ded593ab1c5de": "/8dfc3a86e0bfa8ebce86739587fb6b3b.png",
    "b9178ad15372807698ab436d075e5db86dbbc7ae": "/72d1558ffec8036ae45902e17be79237.jpg",
    "fc98468b612b07b8fdeedbfa911ed1a9db234ad4": "/f3ae69b9992ce7379b9f50f25675ab47.jpg",
    "bcb7a9633440cf1f55a9f4a00270fae7f468755f": "/910aa9bcd49671470b1ac1ab206ab781.png",
    "e5103d62841b7632f4edcf59b94fc3a8f0fe6fc3": "/ab42b983bd8ec1a8e107d335a5b3074d.jpg",
    "4fec9443d96f5fa2c0a6704b92bafbe64ca847dd": "/4df4f8297bc9cc95b9b7e51cec489ea4.png",
    "97edf3e5bf351a717ecbdac41802951f2b9f3250": "/06e54ca417fae5503440a69e3b0a955a.jpg",
    "9cb1863b5bc60940fb347099f25e4e0b88e27b11": "/da2a673b4b348694aa75ec206269f93e.png",
    "d2ff56d3d2f5cb63e19b27b49f5c3a2b8e8d8bdb": "/ecb09fe04f46199dddac4049dce7d135.jpg",
    "a31c64db393ad78109933b35c69e0d45ba3b61b6": "/75b4247fdd3b97d0e3b8e07b115673c2.ttf",
    "99f5f223bca61fd9c00ca3ec3fc2dfc07669d05e": "/d88db58844b8d55402d040e81e2589ec.jpg",
    "f91bfa40878c042659c72cd27ff5096326460073": "/4bb125e48b66834a148b561dc9193bb1.png",
    "aeb5571249815fefdfb3686eaf0444bf59bce7b1": "/7c74c6e7de7bf5dadedf03c0b304295c.svg",
    "e613b2fe006938d28b066851e1c2f58db78e7462": "/b03cc7b0cd3f76a1bcfcaa3704711a21.jpg",
    "ee233a2cd3bb3920d83bb9affae3d00675dd7fc8": "/b86a77f2d5871ba2029b7f890fb7b8dd.jpg",
    "f769996d20e1ee1241b817a59d547e41dab7dd0f": "/9e153768735edc4ed0fb2f1b033bf5f4.jpg",
    "765cdcbfa5a0ed63ddca70ce26f4837ebd16f018": "/758033941cc747f5217ec368434314e1.jpg",
    "195faad7f62bf1c768cb93466e1d27c199bebbb4": "/8e839933a86a6f6bd705cfe828e14955.jpg",
    "4ab381ecd77519206ff3eaf8ad7653cb825b4496": "/7802d8b27fcb19893ce6b38c0789268e.ttf",
    "97d54b21be7b1b66efd82bfd555e5d3b1e3e78ce": "/e0189803d576d6c0bbbdea5cd44399a0.jpg",
    "b9192cf3665d7d21215cf8ffdf7cebe634f7eafc": "/121878e5d8ae0d1b71a5581c5a1d4342.png",
    "7f329802eff5e3b19f9d331f605f32142b934cc8": "/0becfa536b0f09ff258466480ff62bc6.png",
    "af4f07e102f758071509f3b91af7ae68f766e5e5": "/30af3eadb49441a545f69fa9ffa3e0b0.jpg",
    "6d79683d6f2ded5ff592cee98521010400a297e5": "/38b405eba92acbb5aef45d8152f2a736.ttf",
    "62943a10e85ef0678d5430b1912d471ad18c5df8": "/dd5eff093c22e60565058dac94309328.jpg",
    "02bf417ae83f5e44759ccc90d7bb32042850e63a": "/76ca740617fd7c767ed4fe28d109a336.jpg",
    "13ea222f375393f0f043c6565fa645a1978b5040": "/51a723d846f1c5c6f1a8794a9728f39b.jpg",
    "ed511d70088e08cf20a59cbc1e9ffdd53b29e29e": "/4e8206207de39d7524873a3b3c2ba0e4.png",
    "0d1e85d12f07cde23f4b3586f4339e49ab6a2e09": "/0854c2bf4c5166d93899ceb016f84f4a.png",
    "a3919800d5e4e950c84d162ce1b0abd8010f1650": "/2ec8557460d3a2cd7340b16ac84fce32.ttf",
    "dd0a1da9fa779d9ab7980ea9cf6b1801303aa7fd": "/npm.intl.4f570d628d17626bef82.chunk.js",
    "5ea9ed951470f8845f1fb353347aa9005c4111a9": "/main.21df9a0faec5a60ba497.chunk.js",
    "fbebe148b05d098d7757df0441874c9a0b01ba19": "/npm.ant-design.9e820277688125a812f2.chunk.js",
    "4064eb1eddac476bf5831d86e6c2e63d61bf0f45": "/npm.antd.92f33e1f38252f07bd43.chunk.js",
    "6b60027e5ebfde1d3132d1533b829c049f02c54a": "/npm.antv.5c4ba923288144dd282d.chunk.js",
    "a3e4b3067ecefbb3e247d0e58a72397a4b00c2f7": "/npm.core-js.bf8479ba8742ced8a2f4.chunk.js",
    "b1d7f7d21b5f72e0f1caecfe0b8abe0f9641dced": "/npm.dagre.6814a1d78b559504ce37.chunk.js",
    "b09315df72046d8ba96d1ffa5228d22904087875": "/npm.draft-js.c6b4da629b426692df96.chunk.js",
    "ff023254de973d4fb6529dcf81db5532ce1da8fd": "/npm.graphlib.05441218e663c5de62c3.chunk.js",
    "12f44e913839503e9206e6608330b4285e01f32e": "/npm.moment.2fb61346e735533abd37.chunk.js",
    "85bcc277294cbee8a30bf4fe3482c66ff8091940": "/npm.rc-align.a4af2a46dd285eef9329.chunk.js",
    "c0e44cde0672fe2f14725928409c41ddcf8b5bac": "/runtime.fd9503845a78ab8446f1.js",
    "1bf213282292ce0a6ef62f4c9d17b385efcd4e56": "/12.e85530c1149c86b5e89e.chunk.js",
    "e89cab087f5d00a2da2a501be975cee41086f9ae": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "05/11/2022, 23:29:16",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });